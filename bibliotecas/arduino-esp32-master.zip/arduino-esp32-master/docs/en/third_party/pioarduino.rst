#######################################################
pioarduino - (p)eople (i)nitiated (o)ptimized (arduino)
#######################################################

.. warning::
  This tool is **not maintained by the ESP32 Arduino Core team**, so we cannot provide support or guarantee that it will work as expected.

.. note::
  This is a work in progress documentation and we will appreciate your help! We are looking for contributors!

About
-----

For more information, please refer to the `official documentation <https://github.com/pioarduino/platform-espressif32>`_.
